/*

 <stereo_check.h>

*/ 

extern void Set_stereo_parity_of_3D_molecule();
extern void check_3D_stereo_parity_vs_assigned_parity();
extern int  check_stereo_parity_for_MATCH();
extern int neighbors_permutation_number();
