/*

< steep_decen.h >

*/

extern int  steepest_descent_golden_linear_search();
extern void steepest_descent_search_using_only_Eselfclash();
