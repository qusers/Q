/*
 <DualAtomPair.h>

*/

extern void Set_DualAtomPair_Descriptor();
extern void get_param_from_index_of_dual_atompair_descriptor();
