/*
 
 <ioMOL2.h> 
 
*/ 

extern int  Translate_Lines_into_MOL2_Molecule();
extern void Write_MOL2_Molecule();
extern void make_multiple_conf_fname_from_single_conf_fname();
