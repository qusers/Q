/*
 
 <ioSDF.h> 
 

*/ 

extern int  Translate_Lines_into_SDF_Molecule();
extern void Write_SDF_Molecule();
extern void Read_and_Append_SDF_Annotations();
extern int  Set_Atomic_Stereo_Parity_from_2D_BondStereo();
