/*

 <clique.h>
 
 
*/

extern int BronKerbosch_Version1_BitString();
extern int BronKerbosch_Pivot_BitString();
extern void Evaluate_Degree_of_Atom_Pair();
extern int  Delete_Small_Degree_of_Atom_Pair();
extern int  Keep_Only_Maximum_Npair_MATCH();
extern int  Keep_Only_First_K_MATCH();
extern int  Renumbering_MATCHlist();
extern void Init_Bit_String();
extern int  Sum_Bit_String();
extern void Show_Bit_String();
extern int Get_First_Target_Symbol_In_Bit_String();
extern int Get_i_th_Target_Symbol_In_Bit_String();
