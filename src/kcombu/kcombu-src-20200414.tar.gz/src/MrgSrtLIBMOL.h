/*

 <MrgSrtLIBMOL.h>
 
*/

extern struct GRID_CLUSTER *Merge_Sort_List_LIBMOL();
extern void Merge_Sort_Double_Linked_List_LIBMOL();
extern void Insertion_Sort_Double_Linked_List_LIBMOL();
