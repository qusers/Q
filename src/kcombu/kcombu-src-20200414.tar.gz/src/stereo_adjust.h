/*

< stereo_adjust.h >

*/

extern int Adjust_3D_Stereo_for_2D_Stereo_Reference();
extern int Check_sp3_Chirality_for_Stereo_Parity();
