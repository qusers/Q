/*

 <moltopodis.h>
 
*/

extern void Set_Topological_Distance();
extern void set_shortest_path_between_two_atoms();
extern int MaxDiff_Topological_Distance();
extern void show_shortest_pathes_between_atoms();
extern void show_pathmap();
