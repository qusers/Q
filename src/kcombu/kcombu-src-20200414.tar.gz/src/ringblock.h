/*
 
<ringblock.h> 

*/

extern void Set_Ring_Block_and_SSSR_Ring();
